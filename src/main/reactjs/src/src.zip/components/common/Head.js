import React from 'react';

function Head() {
  return (
    <>
    </>
  );
}

export default Head;
