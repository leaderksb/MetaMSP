import React, { useState, useEffect } from 'react';

const AdminNotice = () => {
  return (
    <>
      <h1>Admin Notice</h1>
    </>
  );
};

export default AdminNotice;
