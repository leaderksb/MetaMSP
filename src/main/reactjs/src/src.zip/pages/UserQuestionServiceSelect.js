import React, { useState, useEffect } from 'react';
import axios from 'axios';

const UserQuestionServiceSelect = ({ jsonData }) => {
  // JSON 데이터가 없는 경우, 초기값을 빈 객체로 설정
  const { questionService = {}, qnaList = [] } = jsonData || {};
/////////////////////////////수정중/////////////////////////////
  const handleSubmit = async (e) => {
    const formDataWithInputs = {
      q_category: questionService.qcategory,
      qPrt: questionService.qurl,
      q_title: e.target.q_title_add.value,
      q_content: e.target.q_content_add.value
    };

    console.log(formDataWithInputs);

    e.preventDefault();
    try {
      const response = await axios.post('/api/user/question/service/add', formDataWithInputs);
      alert(response.data);
      if (response.data === 'UserQuestionServiceList') {
        alert('첫 질문을 등록하였습니다.');
        // 폼 데이터 초기화
        formDataWithInputs({
          q_category: '',
          qPrt: '',
          q_title: '',
          q_content: ''
        });
      } else {
        alert('질문 등록에 실패했습니다.');
      }
    } catch (error) {
      console.error('Error submitting question:', error);
      alert('질문 등록에 실패했습니다.');
    }
  };
/////////////////////////////수정중/////////////////////////////
  return (
    <>
      {/* 첫 번째 질문 */}
      <div style={{ width: '50%', margin: '19px auto' }}>
        <h5>Question</h5>
        <table style={{ width: '100%', textAlign: 'center', borderCollapse: 'collapse' }}>
          <colgroup>
            <col style={{ width: '30%' }} />
            <col style={{ width: '70%' }} />
          </colgroup>
          <tr>
            <td style={{ borderLeft: 'none', verticalAlign: 'middle', fontWeight: 'bold' }}>
              <label htmlFor="q_title">Title </label>
            </td>
            <td style={{ borderRight: 'none', verticalAlign: 'middle' }}>
              <span id="q_title_first" name="q_title" style={{ textAlign: 'center', display: 'block' }}>{questionService.qnATitle}</span>
            </td>
          </tr>
          <tr>
            <td colSpan="2" style={{ borderLeft: 'none', borderRight: 'none', verticalAlign: 'middle', fontWeight: 'bold' }}>
              <label htmlFor="q_content">Content</label>
            </td>
          </tr>
          <tr>
            <td colSpan="2" style={{ borderLeft: 'none', borderRight: 'none', verticalAlign: 'middle' }}>
              <p id="q_content_first" name="q_content">{questionService.qnAContent}</p>
            </td>
          </tr>
        </table>
      </div>

      {/* 추가된 질문 및 답변 */}
      {qnaList.map((item, index) => (
        <div key={index} style={{ width: '50%', margin: '19px auto' }}>
          {item.getClass().getSimpleName() === 'QuestionService' ? (
            <>
              <h5>Question</h5>
              <table style={{ width: '100%', textAlign: 'center', borderCollapse: 'collapse' }}>
                <colgroup>
                  <col style={{ width: '30%' }} />
                  <col style={{ width: '70%' }} />
                </colgroup>
                <tr>
                  <td style={{ borderLeft: 'none', verticalAlign: 'middle', fontWeight: 'bold' }}>
                    <label htmlFor="q_title">Title </label>
                  </td>
                  <td style={{ borderRight: 'none', verticalAlign: 'middle' }}>
                    <span id="q_title" name="q_title" style={{ textAlign: 'center', display: 'block' }}>{item.qnATitle}</span>
                  </td>
                </tr>
                <tr>
                  <td colSpan="2" style={{ borderLeft: 'none', borderRight: 'none', verticalAlign: 'middle', fontWeight: 'bold' }}>
                    <label htmlFor="q_content">Content</label>
                  </td>
                </tr>
                <tr>
                  <td colSpan="2" style={{ borderLeft: 'none', borderRight: 'none', verticalAlign: 'middle' }}>
                    <p id="q_content" name="q_content">{item.qnAContent}</p>
                  </td>
                </tr>
              </table>
            </>
          ) : (
            <>
              <h5>Answer</h5>
              <table style={{ width: '100%', textAlign: 'center', borderCollapse: 'collapse' }}>
                <colgroup>
                  <col style={{ width: '30%' }} />
                  <col style={{ width: '70%' }} />
                </colgroup>
                <tr>
                  <td style={{ borderLeft: 'none', verticalAlign: 'middle', fontWeight: 'bold' }}>
                    <label htmlFor="a_title">Title </label>
                  </td>
                  <td style={{ borderRight: 'none', verticalAlign: 'middle' }}>
                    <span id="a_title" name="a_title" style={{ textAlign: 'center', display: 'block' }}>{item.qnATitle}</span>
                  </td>
                </tr>
                <tr>
                  <td colSpan="2" style={{ borderLeft: 'none', borderRight: 'none', verticalAlign: 'middle', fontWeight: 'bold' }}>
                    <label htmlFor="a_content">Content</label>
                  </td>
                </tr>
                <tr>
                  <td colSpan="2" style={{ borderLeft: 'none', borderRight: 'none', verticalAlign: 'middle' }}>
                    <p id="a_content" name="a_content">{item.qnAContent}</p>
                  </td>
                </tr>
              </table>
            </>
          )}
        </div>
      ))}

      {/* 추가 질문 */}
      <div style={{ display: 'flex', justifyContent: 'center', alignItems: 'center', flexDirection: 'column' }}>
        <h5>Question Add</h5>
        <form onSubmit={handleSubmit}>
          <input type="hidden" id="q_category_add" name="q_category_add" value={questionService.qcategory} />
          <input type="hidden" id="qPrt" name="qPrt" value={questionService.qurl} />
          <div>
            <label htmlFor="q_title_add">Title </label>
            <input type="text" id="q_title_add" name="q_title_add" maxLength="100" style={{ width: '316px' }} />
          </div>
          <hr />
          <div>
            <label htmlFor="q_content_add">Content </label>
            <br />
            <textarea id="q_content_add" name="q_content_add" style={{ width: '351px', height: '300px' }}></textarea>
          </div>
          <hr />
          <div style={{ display: 'flex', justifyContent: 'center' }}>
            <button type="submit" value="submit" className="btn btn-primary">질문하기</button>
          </div>
        </form>
      </div>
    </>
  );
}

export default UserQuestionServiceSelect;

