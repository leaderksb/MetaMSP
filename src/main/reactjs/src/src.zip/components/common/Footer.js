import React from 'react';

function Footer() {
  return (
    // 푸터 컴포넌트의 내용을 여기에 작성
    <h1>Footer</h1>
  );
}

export default Footer;
