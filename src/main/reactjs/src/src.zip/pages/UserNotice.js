import React from 'react';

function UserNotice() {
  return (
    <>
      <h1>UserNotice</h1>
    </>
  );
}

export default UserNotice;
