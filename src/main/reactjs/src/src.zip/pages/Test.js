import React, { useState, useEffect } from 'react';
import axios from 'axios';
import DefaultLayout from '../components/layout/DefaultLayout.js';

function Test() {
  const [message, setMessage] = useState('');

  useEffect(() => {
    fetchData();
  }, []);

  const fetchData = async () => {
    try {
      const response = await axios.get('http://localhost:10000/');
        console.log('Test00')
        console.log('서버에서 받은 메시지:', response.data.message);  // 서버에서 받은 메시지를 출력
        setMessage(response.data.message);
        console.log('Test01')
    } catch (error) {
      console.error('Error fetching data:', error);
    }
  };

  return (
    <DefaultLayout>
      {/* Test의 컨텐츠가 여기에 들어갑니다. */}
        <p>--------------------------------------------------</p>
          <div>
            <h1>{message}</h1>
          </div>
        <p>--------------------------------------------------</p>
    </DefaultLayout>
  );
}

export default Test;
